## How do I use CodePlex to download samples and sample databases?

* To download the entire set of SQL Server product samples, click on the releases tab for this portal project, then click on the appropriate installer for your computer.
* To focus on samples for a particular technology on the appropriate **Product** or **Community** link in the sample table on the home portal page.  After clicking on that link you can:
	* Download all the samples for that particular technology area by clicking on the **Releases** tab, then clicking on the desired release in the upper right hand "Releases" box if you want a different release than the one selected by default, then clicking on the appropriate installer for your computer.
	* Browse the source code without downloading by clicking on the **Source Code**, then keep clicking on the appropriate folder icons in the Browse column until you find the particular sample source code you wish.
	* File a bug or check the status of a bug by clicking on the **Issue Tracker** tab.
* To view forum posts or create a new thread of forum posts about samples in either this portal project or a particular Product or Community project click on the **Discussions** tab in that project.

For more information about CodePlex, see [CodePlex Documentation](http://www.codeplex.com/CodePlex/Wiki/View.aspx?title=CodePlex%20Documentation&referringTitle=Home)

## I can't find the sample database installers.  Where are they?
You can find them in the [AdventureWorks Sample Databases project](http://www.codeplex.com/MSFTDBProdSamples).

## When I start the installer (MSI), I get: "The installer has encountered an unexpected error installing this package. This may indicate a problem with this package. The error code is 2738."

![](HowToUseCodePlex_Error Code 2738 Large.png)

* This is a usually a sign that VB Script has been disabled in your o/s; it can usually be fixed by re-registering VB Script as follows:

# Open command window (CMD) as Administrator.
# cd %windir%\System32
# regsvr32 vbscript.dll

## When I install the sample databases I get an error: "Error 1721. There is a problem with this Windows Installer package." Help!

* This is typically caused by trying to use the SQL Server **2008** installers on a SQL Server **2005** instance.  Be sure to download the correct installers for the version of SQL Server you are using.  Try executing **SELECT @@VERSION** using SQL Server Management Studio or SQLCMD if you aren't sure.  The SQL Server **2005** installers are available.  See the directions above for how to use the Releases tab for every project (including the sample database project) to find the right version.  By default SQL Server **2008** installers are shown, but you can select SQL Server **2005** installers if you wish.  Alternatively, you can just find them [here](http://www.codeplex.com/MSFTDBProdSamples/Release/ProjectReleases.aspx?ReleaseId=4004).

## When I try to install CLR samples or the Storefront Sample I get an error: "Msg 15208, Level 16, State 1, Line 1  The certificate, asymmetric key, or private key file does not exist or has invalid format." Help!
* Make sure you've created the sample key files.  See the readme file for the sample you are trying to install for directions on where and how to create the sample key files.
* Make sure the DLLs you compile are configured to be signed with the appropriate sample keys.
* On Vista and newer OSes this is typically caused by a permissions issue.  The service account SQL Server is running under does not have permission to access the DLLs.  For SQL Server 2005 you can use the following procedure:
# Use windows explorer and locate the folder **c:\Microsoft SQL Server\90\Samples** (or where ever you've installed the samples if you changed that location).
# Click right on that folder.
# Click on the security tab.
# Click on the edit button.
# Click on the add button.
# In the “Object name to select” text box enter the _MachineName_**\SQLServer2005MSSQLUser$**_MachineName_$_InstanceName_ group.  For example, if my machine was named AdventureWorksServer with SQL Express installed the default way, the group would be named **SQLServer2005MSSQLUser$AdventureWorksServer$SQLEXPRESS**.
# Click OK until all the dialogs are gone.

## I think the CodePlex UI is hard to use!
* It is true that it takes some getting used to, but we think the extra power and flexibility compared to the download center is worth it.  If you have specific suggestions for how the CodePlex team could improve the user experience, we encourage you to click on [the CodePlex project](http://CodePlex.Com/CodePlex) and file your suggestion using the Issue Tracker tab.  If enough people in the community vote in favor of your suggestion it will be noticed by the team which maintains and improves CodePlex.com.

## Where are the Notification Services samples?
* Notification Services samples are not located in a technology specific project as Notification Services is deprecated in SQL Server 2005 and does not ship in SQL Server 2008 (some scenarios may be included in Reporting Services in a future release).  However if you download all the SQL Server 2005 samples from [here](http://www.codeplex.com/SqlServerSamples/Release/ProjectReleases.aspx?ReleaseId=4000) the Notification Services samples are included.
