## Microsoft SQL Server 2008 CTP and Microsoft SQL Server 2005 Databases and Samples Overview

**Updated: February 2008**

The Microsoft SQL Server sample databases and sample code available on CodePlex.com are designed to work with Microsoft SQL Server 2008 and Microsoft SQL Server 2005.

### AdventureWorks Database
The installers for the AdventureWorks OLTP sample database are located on the Releases tab in the Adventure Works Sample Databases Product project.

The AdventureWorksDB.msi contains the **AdventureWorks** OLTP database files. Completely remove previous installations of the database before running the MSI to extract the database files. To remove a previous download of an AdventureWorks database:
# Drop the **AdventureWorks** or **AdventureWorksDW** database.
# From **Add or Remove Programs**, select **AdventureWorksDB** or **AdventureWorksBI** and click **Remove**.

To remove an AdventureWorks database installed by using setup
# Drop the **AdventureWorks** or **AdventureWorksDW** database.
# From Add or Remove Programs, select **Microsoft SQL Server 2005** and click **Change**.
# From Component Selection, select **Workstation Components** and then click **Next**.
# From Welcome to the SQL Server Installation Wizard, click **Next**.
# From System Configuration Check, click **Next**.
# From Change or Remove Instance, click **Change Installed Components**.
# From Feature Selection, expand the **Documentation, Samples, and Sample Databases node.**
# Select **Sample Code and Applications**.
# Expand **Sample Databases**, select the sample database to be removed and select **Entire feature will be unavailable**. Click **Next**.
# Click **Install** and finish the installation wizard.
If you are using more than one instance of Microsoft SQL Server on the machine where you want to install the database you may need to change the directory where the contents of this MSI is installed in the installation wizard to match the directory where the master database file is located. To determine where the **master** database file is located, from either SQL Server Management Studio or SQL Server Management Studio Express, connect to the instance where you want to install the **AdventureWorks** database. Execute the following query:

 {{ select physical_name from sys.database_files where name = 'master' }} 

The installers for SQL Server 2008 sample databases attach them during installation.  For SQL Server 2005 to use this sample database and the following samples, you must attach the files to an instance of either Microsoft SQL Server Express Edition or Microsoft SQL Server. In either SQLCMD or SQL Server Management Studio, execute a script similar to the following:

 {{ exec sp_attach_db @dbname = N'AdventureWorks', }}
 {{    @filename1 = N'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\AdventureWorks_Data.mdf', }}
 {{    @filename2 = N'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\AdventureWorks_log.ldf' }} 

If you have installed these files to a different drive or directory, you must revise the paths appropriately before you execute the **{"sp_attach_db"}** stored procedure.

**Note**: For Microsoft Windows 2003 and Microsoft Windows XP operating systems you must have a default instance of the server installed in order to successfully install sample databases to a named instance for SQL Server 2008.  

**Note**: If you are having trouble with the SQL Server 2008 database installers when attaching to the default server **(local)** then change the server in the connection dialog to specify the name of your local machine instead.

### AdventureWorks Data Warehouse Database and Analysis Services Project
The installers for the AdventureWorks BI sample database and AS projects are located on the Releases tab in the Adventure Works Sample Databases Product project.
The AdventureWorksBI.msi contains the **AdventureWorksDW** data warehouse database files and the Analysis Services projects for the Standard and Enterprise editions. **AdventureWorksDW** and the Analysis Services projects are not supported in SQL Server Express. Remove previous installations of the **AdventureWorksDW** database and Analysis Services projects before running this MSI. See the above instructions on how to remove previous installations of the database. Also see the above instructions about how to install these files if you have multiple instances on your server. The installers for SQL Server 2008 sample databases attach them during installation. For SQL Server 2005 to use this sample database and the following samples, you must attach the files to an instance of either Microsoft SQL Server Express Edition or Microsoft SQL Server. In either SQLCMD or SQL Server Management Studio, execute a script similar to the following:

 {{exec sp_attach_db @dbname=N'AdventureWorksDW', }}
 {{    @filename1=N'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\AdventureWorksDW_Data.mdf', }}
{{   @filename2=N'C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\AdventureWorksDW_log.ldf'}} 

If you have installed these files to a different drive or directory, you will have to revise the paths appropriately before you execute the **{"sp_attach_db"}** stored procedure.  Note that you must detach the database in order to uninstall it.  By default the Analysis Services projects are installed to _drive_**:\Program Files\Microsoft SQL Server\100\Tools\Samples\AdventureWorks Analysis Services Project** for SQL Server 2008 and _drive_**:\Program Files\Microsoft SQL Server\90\Tools\Samples\AdventureWorks Analysis Services Project** for SQL Server 2005. To deploy the project, perform the following steps:
# From the **SQL Server Business Intelligence Development Studio** tool bar, click **File**, point to **Open** and then click **Project/Solution**.
# Browse to _drive_**:\Program Files\Microsoft SQL Server\100\Tools\Samples\AdventureWorks Analysis Services Project** for SQL Server 2008 and_drive_**:\Program Files\Microsoft SQL Server\90\Tools\Samples\AdventureWorks Analysis Services Project** for SQL Server 2005, select the file **Adventure Works.sln** in either the Enterprise or Standard folder and click **Open**.  Use the solution in the Standard folder if you are using the Standard edition of SQL Server, otherwise use the solution in the Enterprise folder for other supported editions.
# From **Solution Explorer**, right-click **Adventure Works DW** and select **Deploy** or **Process**.

**Note**: If you are having trouble with the SQL Server 2008 database installers when attaching to the default server **(local)** then change the server in the connection dialog to specify the name of your local machine instead.

### SQL Server Samples
Installers for the complete set of SQL Server code samples are located on the Releases tab of this project.  You can also click on the Releases tab of other product sample projects for installers for that particular technology area of SQL Server.
The SqlServerSamples.msi contains samples for Microsoft SQL Server and Microsoft SQL Server Express Edition. Most of the samples have been developed in both Microsoft Visual C# and Microsoft Visual Basic .NET. Samples that do not work on SQL Server Express are noted in the description of the sample. Run the MSI to extract the
samples. Unless you specify otherwise, the samples are installed in _drive_**:\Program Files\Microsoft SQL Server\100\Samples** for SQL Server 2008 and _drive_**:\Program Files\Microsoft SQL Server\90\Samples** for SQL Server 2005. To execute the Transact-SQL scripts on SQL Server Express, use the following parameters with **SQLCmd**:

 **{{SQLCmd -S}}**  _{{servername}}_**{{\}}**_{{instancename}}_ **{{-E -I -i}}** _{{filename}}_**{{.sql}}**

**Note:** If you are executing samples in a named instance as is the default for SQL Server Express you may need to modify some of the scripts in order to run the sample correctly.  Some samples assume they are being executed in the default instance.

**Note:** To run the SMOPing sample, make sure you pass in the server name and instance with no space, for example: 

**{{SMOPing.exe -S}}** _{{servername}}_**{{\}}**_{{instancename}}_

Vista is supported for most samples except as otherwise noted.  You will have have to install these MSIs running as a privileged administrator on Vista.

Note that although a sample ReadMe file may indicate that the sample works correctly in both SQL Server 2005 and SQL Server 2008, you must download and use the correct installer for the version of SQL Server you are using.  A sample from the SQL Server 2005 distribution may not work correctly on SQL Server 2008 and visa versa.

The SQL Server 2008 February 2008 CTP contains samples which will support the SQL Server 2008 February 2008 CTP release of SQL Server.

New samples for the SQL Server 2008 February 2008 CTP include
Data Access (ODBC):
* [Table Valued Parameters](#TableValuedParameters)
* [Date and Time data structures](#DateandTimedatastructures)
* [Filestream incremental send and receive](#Filestreamincrementalsendandreceive)
* [Integrated Kerberos authentication](#IntegratedKerberosauthentication)

Data Access (OLE DB):
* [Filestream send using ISequentialStream](#FilestreamsendusingISequentialStream)
* [Filestream Retrieve](#Filestream-Retrieve)
* [Filestream Fast Upload](#FilestreamFastUpload)
* [Filestream Retrieve with IBCPSession](#FilestreamRetrievewithIBCPSession)
* [Date and Time](#DateandTime)
* [Changing a Password](#ChangingaPassword)
* [Sparse column metadata](#Sparsecolumnmetadata)
* [Kerberos authentication](#Kerberosauthentication)

Integration Services (SSIS):
* [The Integration Services tutorial samples](#CreatingaBasicPackage)

The SQL Server 2008 November 2007 CTP contains samples which support the SQL Server 2008 November 2007 CTP release of SQL Server.

New samples for the SQL Server 2008 November 2007 CTP include
SQL Server Integration Services:
* [#LookupTransformation](#LookupTransformation)

Service Broker:
* [#ConversationPriority](#ConversationPriority)

New or significantly updated samples for the SQL Server 2005 February 2007 web refresh include
Analysis Services:

*  [#AggregationManager](#AggregationManager) 
*  [#ASTrace](#ASTrace) 
*  [#ASUV](#ASUV) 
*  [#ASSimpleSample](#ASSimpleSample) 
Integrated Samples:

*  [#DB3D](#DB3D) 
New or significantly updated samples added for the SQL Server 2005 July 2006 web refresh include
Analysis Services:

*  [#ASCMD](#ASCMD) 
Data Access (ODBC):

*  [#MirroringFailover](#MirroringFailover) 
Transact-SQL:

*  [#Alerts](#Alerts) New samples added for the SQL Server 2005 April 2006 web refresh
include
Analysis Services:

*  [#ASCMD](#ASCMD) 
Data Access (OLEDB)

*  [#BulkCopyRecords](#BulkCopyRecords) 
*  [#FetchColumns_A](#FetchColumns_A) 
*  [#FetchColumns_B](#FetchColumns_B) 
*  [#FetchRowsFromResultSet](#FetchRowsFromResultSet) 
*  [#GetFastForwardCursor](#GetFastForwardCursor) 
*  [#GetRowsUsingBookmark](#GetRowsUsingBookmark) 
*  [#InitializeAndEstablishConnection_A](#InitializeAndEstablishConnection_A) 
*  [#InitializeAndEstablishConnection_B](#InitializeAndEstablishConnection_B) 
*  [#InitializeAndEstablishConnection_C](#InitializeAndEstablishConnection_C) 
*  [#ListDataSourcesWithEnumerator](#ListDataSourcesWithEnumerator) 
*  [#WorkingWithBLOBs](#WorkingWithBLOBs) 
Data Access (ODBC)

*  [#BulkCopyFormatAndData](#BulkCopyFormatAndData) 
*  [#BulkCopyFromVariables](#BulkCopyFromVariables) 
*  [#BulkCopyNativeMode](#BulkCopyNativeMode) 
*  [#BulkCopySelectResult](#BulkCopySelectResult) 
*  [#BulkCopyWithFormat](#BulkCopyWithFormat) 
*  [#CreateAndDisplayPerformanceLog](#CreateAndDisplayPerformanceLog) 
*  [#LogLongRunningQuery](#LogLongRunningQuery) 
*  [#ProcessODBCErrors](#ProcessODBCErrors) 
*  [#ProcessReturnCodes](#ProcessReturnCodes) 
*  [#UseDataAtExecutionColumns](#UseDataAtExecutionColumns) 
*  [#UseDataAtExecutionParameters](#UseDataAtExecutionParameters) 
Common Language Runtime (CLR) Integration:

*  [#CurrencyWebService](#CurrencyWebService) 
*  [#TimeSeries](#TimeSeries) 
Integration Services

*  [#HtmlLogProvider](#HtmlLogProvider) 
*  [#Excel2ConnectionManager](#Excel2ConnectionManager) 
*  [#Email Log Provider](#Email-Log-Provider) 
*  [#Creating a Basic Package](#Creating-a-Basic-Package) 
*  [#Deploying Packages](#Deploying-Packages) 
Replication

*  [#SalesOrderMobile](#SalesOrderMobile) 

New samples added for the SQL Server 2005 December 2005 web refresh include
Common Language Runtime (CLR) Integration:

*  [#OracleTVF](#OracleTVF) 
*  [#SendDataSet](#SendDataSet) 
*  [#Transactions](#Transactions) 
Server Management Objects (SMO):

*  [#CheckIdentityValues](#CheckIdentityValues) 
*  [#DatabaseDefrag](#DatabaseDefrag) 
*  [#DatabaseSpace](#DatabaseSpace) 
*  [#IndexSizes](#IndexSizes) 
*  [#RebuildAllIndexes](#RebuildAllIndexes) 
*  [#ServiceBrokerConfiguration](#ServiceBrokerConfiguration) 
*  [#SmoScripter](#SmoScripter) 
Integration Services:

*  [#RemoveDuplicatesUI](#RemoveDuplicatesUI) 
*  [#SqlConnectionManager](#SqlConnectionManager) 
Replication:

*  [#ActiveXControl](#ActiveXControl) 
Reporting Services

*  [#Polygons](#Polygons) 
*  [#ReportBuilder](#ReportBuilder) 
*  [#ReportSearch](#ReportSearch) 

The following is a complete list of samples, with their descriptions, organized by technology.


####  {anchor:_ADO.NET}  ADO.NET

| **Sample name**| **Description** |
|  Reading and Writing Large Binary Data |  Programmatically reads binary data from a file into a database. Also retrieves binary data stored in the database and writes the contents to a file.  |
|  MARS |  Demonstrates issuing multiple commands in parallel on the same connection.  |



####  {anchor:_OLEDB}  Data Access (OLEDB)

| **Sample name**| **Description** |
|  {anchor:BulkCopyRecords} BulkCopyRecords |  Illustrates the use of IRowsetFastLoad for bulk copying of the records into a table.  |
|  {anchor:FetchColumns_A} FetchColumns_A |  This sample shows how to fetch a single row using IRow.  |
|  {anchor:FetchColumns_B} FetchColumns_B |  This sample shows how to use the IRow interface to allow direct access to columns of a single row in the result set.  |
|  {anchor:FetchRowsFromResultSet} FetchRowsFromResultSet |  Shows how to fetch rows from a result set.  |
|  {anchor:GetFastForwardCursor} GetFastForwardCursor |  This sample shows how to set the rowset properties to obtain a FAST_FORWARD cursor.  |
|  {anchor:GetRowsUsingBookmark} GetRowsUsingBookmark |  This sample shows how to fetch rows using a bookmark.  |
|  {anchor:InitializeAndEstablishConnection_A} InitializeAndEstablishConnection_A |  This example shows processing a rowset, a return code, and an output parameter using ODBC Call syntax.  |
|  {anchor:InitializeAndEstablishConnection_B} InitializeAndEstablishConnection_B |  Demonstrates processing a rowset, a return code, and an output parameter using RPC syntax.  |
|  {anchor:InitializeAndEstablishConnection_C} InitializeAndEstablishConnection_C |  Executes a user-defined function and prints a return code.  |
|  {anchor:ListDataSourcesWithEnumerator} ListDataSourcesWithEnumerator |  Shows how to use the enumerator object to list the data sources available.  |
|  {anchor:WorkingWithBLOBs} WorkingWithBLOBs |  Shows how to set binary large object (BLOB) data, create a table, add a sample record, fetch that record in the rowset, and then set the value of the BLOB field.  |
|  {anchor:FilestreamsendusingISequentialStream} Sending data to a Filestream column using ISequentialStream bound to ICommandText parameter | This sample uses an ISequentialStream interface bound to an ICommandText parameter to send between 4MB and 4GB of data to a filestream column.  |
|  {anchor:FilestreamRetrieve} Retrieve data from Filestream column using ISequentialStream | Shows how to use an ISequentialStream interface in an ICommandText interface to retrieve a single record from a Filestream column.  |
|  {anchor:FilestreamFast Upload} Sending Data to a Filestream column using IRowsetFastUpload | This sample uses the IRowsetFastUpload interface to send between 4MB and 4GB of data to a filestream column.  |
|  {anchor:FilestreamRetrievewithIBCPSession} Reading a Filestream column to a file using IBCPSession | This sample reads a filestream column to a file using the IBCPSession interface and writes a format file.  |
|  {anchor:DateandTime} Enhanced Date/Time Features | This sample shows how to use the date/time features in OLE DB introduced in SQL Server 2008.  The sample uses the four new date and time types (date, time, datetime2, and datetimeoffset) to execute commands with parameters and retrieve rowset results.  |
|  {anchor:ChangingaPassword} Changing a SQL Server Authentication User Password | This samples shows how to use OLE DB to change the password of a user account under SQL Server Authentication.  |
|  {anchor:Sparsecolumnmetadata} Displaying column and catalog metadata for sparse columns | This sample creates a table with three columns: a sparse column, a column that is not a sparse column, and a columnset column.  The sample then displays OLE DB flags showing the column and catalog metadata for the non-sparse column and columnset column.  |
|  {anchor:Kerberosauthentication} Integrated Kerberos Authentication Sample | This sample shows how to get mutual Kerberos authentication by using OLE DB in SQL Server Native Client.  |




####  {anchor:_ODBC}  Data Access (ODBC)

| **Sample name**| **Description** |
|  {anchor:BulkCopyFormatAndData} BulkCopyFormatAndData |  This sample shows how to use the ODBC bcp_init function with a format file.  |
|  {anchor:BulkCopyFromVariables} BulkCopyFromVariables |  This sample shows how to do a bulk copy from program variables bound with bcp_bind; data sent with bcp_sendrow.  |
|  {anchor:BulkCopyNativeMode} BulkCopyNativeMode |  This sample shows how to bulk copy without a format file.  |
|  {anchor:BulkCopySelectResult} BulkCopySelectResult |  This sample shows how to bulk copy and write the result set of a SELECT statement.  |
|  {anchor:BulkCopyWithFormat} BulkCopyWithFormat |  This sample shows how to create a bulk copy format file.  |
|  {anchor:CreateAndDisplayPerformanceLog} CreateAndDisplayPerformanceLog |  This sample shows the SQL Server ODBC driver-specific options to record performance statistics.  |
|  {anchor:LogLongRunningQuery} LogLongRunningQuery |  This sample shows the SQL Server ODBC driver-specific options to log long-running queries. When run, creates Odbcqry.log, which contains a list of queries whose execution exceeds an interval set by the application.  |
|  {anchor:ProcessODBCErrors} ProcessODBCErrors |  The sample shows a simple error handler that calls SQLGetDiagRec for the standard ODBC information. It then tests for a valid connection, and if there is, it calls SQLGetDiagField for the Microsoft SQL Server ODBC driver-specific diagnostic fields.  |
|  {anchor:ProcessReturnCodes} ProcessReturnCodes |  This sample shows processing a return code and output parameter.  |
|  {anchor:UseDataAtExecutionColumns} UseDataAtExecutionColumns |  The sample shows how to read a SQL_LONG variable character data using SQLGetData.  |
|  {anchor:UseDataAtExecutionParameters} UseDataAtExecutionParameters |  The sample shows how to read SQL_LONG variable character data using SQLParamData and SQLPutData.  |
|  {anchor:MirroringFailover} Mirroring Failover |  This sample demonstrates the mirroring failover feature in SQL Server 2005 SP1. **This sample is not supported in SQL Server Express.** |
|  {anchor:TableValuedParameters} Table-Valued Parameters | This sample shows how to use table-valued parameters to insert multiple rows, with multiple columns, with one call to the server. |
|  {anchor:DateandTimedatastructures} Date and Time data structures | This samples shows how to initialize the date/time data structures that were added in SQL Server 2008.  It prepares the input values, binds parameters, and executes the query. |
|  {anchor:Filestreamincremental send and receive} Send and Receive data incrementally with Filestream | This sample shows how to use the Filestream feature to send and receive data incrementally with SQLPutData and SQLGetData.  |
|  {anchor:IntegratedKerberosauthentication} Integrated Kerberos Authentication Sample | This sample shows how to get mutual Kerberos authentication by using ODBC in SQL Server Native Client.  |




####  {anchor:_Common_Language_Runtime_(CLR)_Integ}  Common Language Runtime(CLR) Integration

| **Sample name**| **Description** |
|  AdventureWorks CLR Layer |  The AdventureWorks CLR Integration Layer sample for Microsoft SQL Server provides some useful utilities that form an extra layer of functionality on top of the base **AdventureWorks** sample database.The first utility creates contact records for various types of people involved in the **AdventureWorks** database. The contact information is specified by using XML and is passed to a C#-based stored procedure. The second utility defines a **Currency** user-defined data type by using C#. This user-defined data type encapsulates both an amount and a culture which helps determine the correct way to render the amount as a currency value in that culture. The third utility provides a currency conversion function that returns an instance of the **Currency** user-defined type. If the **AdventureWorks** database has a conversion rate from USD to the correct currency associated with the specified culture, the conversion function returns a **Currency** user-defined type that has the converted rate and a culture that matches the requested culture. Otherwise, a **Currency** user-defined type is returned with the original amount (which should be in USD) with the en-us culture.The utilities also demonstrate how to unregister and register common language runtime (CLR) methods and assemblies by using Transact-SQL.  |
|  ArrayParameter |  Demonstrates how to pass an array of information from a client to a CLR integration stored procedure on the server using a CLR integration user-defined data type.  |
|  AssemblyCleanup |  The AssemblyCleanup sample contains a .NET Stored Procedure, written in C#, that cleans-up unused assemblies in the current database by querying the metadata catalogs.  |
|  Calendar-Aware Date/Time UDTs |  The CADatetime sample defines two user-defined data types (CADatetime and CADate) which provide calendar-aware handling of dates and times.  |
|  {anchor:CurrencyWebService} CurrencyWebService |  The Currency Web Service sample for SQL Server demonstrates how to invoke a Web service from server-side common language runtime code. Suppose that there is a Web server available somewhere which can supply current currency exchange information. This sample demonstrates how to expose the result of calling that Web service as a common language runtime-based table valued function (TVF). This table valued function could be used, for example, to periodically insert new rows into the Sales.CurrencyRate rate table in the AdventureWorks database. A simple implementation of the Web service is provided to demonstrate the complete scenario, but the data used in the sample is fictitious. **This sample is not supported in SQL Server Express.** |
|  Hello World |  The Hello World sample demonstrates the basic operations that are involved in creating, deploying, and testing a simple CLR integration-based stored procedure. This sample also demonstrates how to return data via an output parameter and via a record, which is dynamically constructed by the stored procedure and returned to the client.  |
|  Hello World Ready Sample | The Hello World Ready sample demonstrates the basic operations that are involved in creating, deploying, and testing a simple world ready CLR integration-based stored procedure. A world ready component can be easily localized into different languages for different markets around the world without changing the component's source code. This sample also demonstrates how to return data through an output parameter and through a record, which is dynamically constructed by the stored procedure and returned to the client. |
|  Handling LOB using CLR |  Demonstrates using CLR stored procedures to transfer large binary objects between a SQL Server database and files accessible to the server. It also demonstrates registering and dropping CLR stored procedures and assemblies, invoking CLR stored procedures, performing data access from CLR stored procedures, invoking Transact-SQL stored procedures from CLR stored procedures, and using a file to log errors during processing of server-side code.  |
|  Impersonation Sample |  The Impersonation sample demonstrates how to use impersonation to use the credentials passed from the client to access operating system protected resources, such as files, when you are using integrated security.  |
|  In-Process Data Access Sample |  This sample contains several simple functions that demonstrate various features of the CLR Integration in-process data access provider.  |
|  {anchor:OracleTVF} Oracle TVF  (December 2005) |  Demonstrates how to invoke the managed code interface to Oracle to expose the results of any Oracle query as a table-valued function.  |
|  Result Set Sample |  This sample demonstrates how to use server-side cursors to get around absence of Multiple Active Result Set (MARS) support for server side programming.  |
|  {anchor:SendDataSet} Send DataSet  (December 2005) |  Demonstrates how to return an ADO.NET based DataSet within a server side CLR-based stored procedure as a result set to the client.  |
|  Spatial |  This sample demonstrates how to use SQL Server's CLR based Table Valued Functions to implement spatial indexing which enables complex high performance spatial queries. This same technique may be used to index many other kinds of data which is not natively indexed by SQL Server for many different types of applications.  |
|  String Manipulate |  This sample shows the implementation of five Transact-SQL string functions that provide the same string-manipulate functions as built-in functions, but with the additional surrogate-aware capability to handle both Unicode and surrogate strings. The five functions are: **len_s()**, **left_s()**, **right_s()**, **sub_s()**, and **replace_s()**.  Using these functions is the same as using LEN(), LEFT(), RIGHT(), SUBSTRING(), and REPLACE() in string type functions.  |
|  String Manipulation (UTF8) |  This sample shows the implementation of a UTF-8 user-defined data type that extends the type system of the database to provide storage for UTF-8 encoded values. This type also implements code to convert Unicode strings to and from UTF-8.  |
|  String Split Table-Valued Function |  This sample contains a streaming table-valued function, written in C# that splits a comma-separated string into a table with one column. It also contains an aggregate function that converts a string column to a comma-separated string.  |
|  {anchor:Transactions} Transaction  (December 2005) |  Demonstrates controlling transactions by using the managed APIs located in the **System.Transactions** namespace.  |
|  {anchor:TimeSeries} TimeSeries |  This sample demonstrates techniques for analyzing time-varying data using CLR integration.  |
|  User-defined Type Sample |  This sample shows creating and using a simple user-defined data type from both a Transact-SQL and a client application by using * {{System.Data.SqlClient}} *. |
|  User-defined Type Utility Sample |  This sample contains several utility functions that include functions to expose assembly metadata to Transact-SQL and sample streaming table-valued functions to return the types in an assembly as a table, and also to return the fields, methods, and properties in a user-defined type.  |
|  UTF8 String User-Defined Data Type (UDT) |  This sample shows the implementation of a UTF8 user-defined data type that extends the type system of the database to provide storage for UTF8-encoded values. This type also implements code to convert Unicode strings to and from UTF8.  |

 {anchor:_Server_Management_Objects_(SMO)}  


#### Server Management Objects (SMO)
**Note: SMO Samples are not currently supported on the Vista operating system on 64 bit machines for SQL Server Express.**

| **Sample name**| **Description** |
|  BackupRestore |  Demonstrates how to back up and restore a database.  |
|  {anchor:CheckIdentityValues} CheckIdentityValues  (December 2005) |  Performs identity checks on each table in the selected database.  |
|  CreateStoredProcs |  Demonstrates how to create a SELECT stored procedure for each table in the selected database.  |
|  {anchor:DatabaseDefrag} DatabaseDefrag  (December 2005) |  Demonstrates techniques for implementing database defragmentation capabilities in database applications.  |
|  {anchor:DatabaseSpace} DatabaseSpace  (December 2005) |  Demonstrates techniques for implementing database space monitoring applications.  |
|  DependencyExplorer |  Demonstrates techniques for implementing an object explorer to view object dependencies within a database.  |
|  {anchor:IndexSizes} IndexSizes  (December 2005) |  Demonstrates techniques for implementing database index space monitoring applications.  |
|  ManageTables |  Demonstrates how to create, modify, and drop tables.  |
|  LoadRegAssembly |  Demonstrates how to load and register a .NET Framework assembly into an instance of SQL Server. Uses the UtilityConversion assembly.  |
|  ManageDatabases |  Demonstrates how to create, modify, and drop a database. Includes adding a new file group and log file.  |
|  ManageDatabaseUsers |  Demonstrates how to add, modify, and remove users.  |
|  {anchor:RebuildAllIndexes} RebuildAllIndexes  (December 2005) |  Rebuilds all the indexes in the selected database.  |
|  ScriptTable |  This sample lets users script the creation or deletion of tables in the selected database.  |
|  ServerConnect |  Demonstrates how to connect to an instance of SQL Server.  |
|  ServerInfo |  Displays a list of server and connection properties for the selected instance of SQL Server.  |
|  {anchor:ServiceBrokerConfiguration} ServiceBrokerConfiguration |  Demonstrates how to create Service Broker objects including Endpoints and Remote Service Bindings by using SMO. In addition, the sample shows how to create a configuration tool with user controls.  |
|  SmoBrowser |  This sample allows browsing hierarchy of SMO objects using .NET reflection. It shows how exactly SMO represent database objects with all their collections and properties.  |
|  SmoCompare |  This sample demonstrates techniques for implementing a comparison of two database objects.  |
|  SmoEvents |  This sample demonstrates techniques for displaying SQL Server events in a console database application.  |
|  SMOPing |  A console application that connects to the selected instance of SQL Server and displays selected properties. Can be used to check the SQL connection.  |
|  {anchor:SmoScripter} SmoScripter   (December 2005) |  Demonstrates scripting and retrieving database object dependencies.  |
|  SqlServerList |  This sample demonstrates two techniques for retrieving a list of computers that are running SQL Server on the network to the list boxes.  |
|  SQLService |  Displays the SQL Server services that are available to start, stop, pause, and resume. **This sample uses the WMI provider. The WMI provider is not supported in SQL Server Express.** |
|  Tracer |  This sample demonstrates techniques for implementing profile trace from the local instance of SQL Server to the output console. **This sample is not supported in SQL Server Express.** |
|  UtilityConversion |  Used with LoadRegAssembly. Contains demonstration CLR functions that can be used with SQL Server.  |




####  {anchor:_Service_Broker}  Service Broker
**Note: Only the Service Broker client is included in SQL Server Express.**

| **Sample name**| **Description** |
|  Conversation Priority | {anchor:ConversationPriority}The Conversation Priority sample provides a simple Service Broker application that shows you how to use broker priorities for sending and receiving a messages using Service Broker. |
|  EventLogging |  This sample shows how to use Event Notifications to log events in SQL Server. The sample creates a service that receives event notifications and a service program that receives the event notification messages and logs the information in the messages. The service program demonstrates two different ways to log event notification messages. One approach extracts important information from the event notification message and saves the key information and the original message in a log table. The other approach extracts all of the information from the event notification message, saves this information in a log table, and discards the original message. **Only the Service Broker client is included in SQL Server Express.** |
|  HelloWorld |  This sample provides a small example that sends and receives a message by using Service Broker. The sample creates two services and sends a message from one service to the other. The sample includes a script that receives and displays the message. **Only the Service Broker client is included in SQL Server Express.** |
|  HelloWorld_CLR |  This sample provides a small example that sends and receives a message by using the object-oriented interface to Service Broker that is defined in the ServiceBrokerInterface sample. **Only the Service Broker client is included in SQL Server Express.** |
|  ServiceBrokerInterface |  This sample provides a CLR-based object oriented interface for using Service Broker. **Only the Service Broker client is included in SQL Server Express.** |
| ShoppingCart |  This sample uses the conversation group identifier to maintain state for a simple shopping cart application. This sample uses the ServiceBrokerInterface sample. **Only the Service Broker client is included in SQL Server Express.** |



#### {anchor:_Transact-SQL}  Transact-SQL

| **Sample name**| **Description** |
|  AdventureWorks Scripts |  Provides two alternatives to using the schemas in **AdventureWorks**. For more information, see "Schemas in AdventureWorks" in SQL Server Books Online.  |
|  {anchor:Alerts} Alerts |  Demonstrates how to associate actions with various administrative and performance events. For more information, see "Defining Alerts" in SQL Server Books Online. **This sample is not supported in SQL Server Express.** |
|  Create DatabaseSnapshot |  Creates a database snapshot of the **AdventureWorks** sample database. **This sample is not supported in SQL Server Express.** |
|  Create FileGroups |  Creates two new file groups for the **AdventureWorks** sample database. **This sample is not supported in SQL Server Express.** |
|  Sliding Window Script |  This sample demonstrates the ability to move partitions between tables by using the Transact-SQL  {{ALTER TABLE SWITCH}}  statement. **This sample is not supported in SQL Server Express.** |
|  Table and Index Partitioning Script |  Demonstrates table and index partitioning capabilities of SQL Server 2005. **This sample is not supported in SQL Server Express.** |




####  {anchor:_XML}  XML

| **Sample name**| **Description** |
|  On-line Manufacturing Instructions |  Retrieves manufacturing instructions, XML documents and XML illustration diagrams, and applies XSL transformation. The formatted HTML document is then shown in the browser. **This sample uses  {{CREATE ENDPOINT}} , which is not supported in SQL Server Express.** |
|  On-line Product Catalog |  Retrieves catalog-description XML documents and product photo images, and applies XSL transformation. The formatted HTML document is shown in the browser. **This sample uses  {{CREATE ENDPOINT}} , which is not supported in SQL Server Express.** |
|  On-line Store Survey |  Conducts an on-line reseller survey and stores the survey in the **Demographics** column of the **Store** table. **This sample uses  {{CREATE ENDPOINT}} , which is not supported in SQL Server Express.** |




####  {anchor:_Integrated_Samples}  End to End (Integrated) Samples

| **Sample name**| **Description** |
|  {anchor:DB3D} DB3D |  The DB3D sample stores, visualizes, and manipulates tri-dimensional wireframe models by using SQL Server and the Microsoft .NET Framework.  |
|  HRResume |  The HRResume sample allows the user to search for and display XML resumes by using relational and full-text techniques in a specific language. Only basic functionality is provided in this release. Additional features may be added in future releases. **This sample is not supported in SQL Server Express.** |
|  Storefront E-Commerce site |  The Storefront sample provides a traditional e-commerce shopping experience for the goods sold by the fictitious Adventure Works Cycle manufacturing, wholesale, and retail organization. This sample demonstrates several different SQL Server technologies. These technologies include CLR Integration, Service Broker, business intelligence, recursive queries, and various Microsoft .NET Framework 2.0 technologies, including ASP.NET 2.0.**This sample is not supported in SQL Server Express.** |




####  {anchor:_Replication}  Replication

| **Sample name**| **Description** |
|  {anchor:ActiveXControl} ActiveX Control Sample  (December 2005) |  This sample demonstrates how to use the legacy Replication ActiveX Controls to synchronize a subscription from a native code application.  This sample is not supported for SQL Server 2008. |
|  {anchor:SalesOrderMobile} SalesOrderMobile |  This sample is the SQL Server Mobile Subscriber version of the Sales Orders Sample for Merge Replication. This sample highlights using Microsoft SQL Server CE as a Subscriber in a merge replication topology for delivering data to mobile users. It also demonstrates the programmability features of replication in SQL Server Mobile. The sample is a Windows Forms-based application that uses standard Microsoft data access technologies and merge replication to enable a salesperson to maintain her own local data while synchronizing periodically with the home office. The publication used by this sample is created when you install the Sales Orders Sample for Merge Replication.  |
|  Sales Order Sample for Merge Replication |  This sample highlights how a merge replication topology can be implemented to deliver data to mobile users, and it also demonstrates the programmability features of merge replication in SQL Server. The sample is a Windows Forms-based application that uses standard Microsoft data access technologies and merge replication to enable a salesperson to maintain local data while periodically synchronizing with the home office. **This sample is not supported in SQL Server Express.** |
|  Subscriber Monitor Utility Sample for Merge Replication |  The Subscriber Monitor Utility sample is a Windows application that demonstrates how the Subscriber-side monitoring functionality provided by Replication Management Objects (RMO) is used to monitor merge subscriptions at the Subscriber.  |

 {anchor:_Analysis_Services}  



####  {anchor:_Analysis_Services_1}  Analysis Services
**Samples in this section are not supported in SQL Server Express.**

| **Sample name**| **Description** |
|  ActivityViewer |  The Activity Viewer sample is a tool that displays users, connections, and processes for an Analysis Services server. The tool lets you get a list of these items and, if necessary, stop a process.  |
|  {anchor:AggregationManager} AggregationManager |  The Aggregation Manager is a tool which lets you view, design, edit, and add aggregations based on the information collected in the query log.  |
|  {anchor:ASCMD} ASCMD |  The ascmd command-line utility enables a database administrator to execute an XMLA script, MDX query, or DMX statement against an instance of Microsoft SQL Server Analysis Services (SSAS). This command-line utility contains functionality similar to the sqlcmd Utility that is included with SQL Server, but for Analysis Services. The execution results of the script, query, or statement can be stored in a file together with relevant SQL Server Profiler trace information. New in the July 2006 release of ascmd is two new features. The first is the ability to execute custom XMLA requests. Using this feature you will be able to execute XMLA Discovers and XMLA Executes. For example, you are able to determine what databases are on an SSAS instance. You are be able to execute statements that change the default properties so the only the data is returned; not the schema  and the data. Second, ascmd now detects if the XMLA input stream is a valid XMLA Command or not. If it is not a valid XMLA Command then it assumes that it is an XMLA Statement and it automatically html encode the input and wraps a <Statement>...</Statement> element around it. This allows you to enter simpler input files when entering MDX queries and DMX statements. See the ascmd readme for more information.  |
|  {anchor:ASTrace} ASTrace |  The ASTrace utility provides you with the ability to capture an Analysis Services trace and log it into a SQL Server table. The table can then be queried later or read using SQL Server Profiler.  |
|  {anchor:ASUV} ASUV |  The Analysis Services Upgrade Verification tool lets you compare Multidimensional Expressions (MDX) query results and performance between a Microsoft SQL Server 2000 Analysis Services databases and a Microsoft SQL Server 2005 Analysis Services database.  This tools helps you verify that your upgrade from SQL Server 2000 to SQL Server 2005 was successful.  |
|  AMOAdventureWorks |  This is a sample C# program that illustrates the use of the Analysis Services Management Objects (AMO) to create complex OLAP cubes.  |
|  AMOBrowser |  The AMOBrowser sample lets you use AMO objects to connect to a Microsoft SQL Server Analysis Services (SSAS) server and then browse different AMO objects and their properties.  |
|  {anchor:ASSimpleSample} AS Simple Sample (AMO) |  The AS Simple Sample is a C# program that illustrates the use of the Analysis Management Objects (AMO) to create complex OLAP cubes and the use of ADOMD.Net to access the contents of the newly created cubes.  |
|  Backup and Restore |  The Backup and Restore sample lets you use AMO objects to connect to a Microsoft SQL Server Analysis Services (SSAS) server. You can then complete a backup of the Analysis Services database, restore the backup, or delete the backup.  |
|  Data Mining Web Controls |  Data Mining Web Controls Library is a library intended to extend the data mining user experience in Microsoft SQL Server 2005 Analysis Services (SSAS) to the Web. This library provides a lightweight version of the data mining model viewers. Using Data Mining Web Controls, you can browse complex mining models from any computer that has Microsoft Internet Explorer installed.  |
|  Data Mining Plug-in Algorithms |  This tutorial steps you through the process of implementing a plug-in algorithm and integrating that algorithm into Analysis Services.  |
|  Display Objects Name |  The Display Objects Name sample lets you use AMO objects to connect to a Microsoft SQL Server Analysis Services (SSAS) server and then display the names of the AMO objects.  |




####  {anchor:_Full-Text_Search}  Full-Text Search
**Samples in this section are not supported in SQL Server Express.**

| **Sample name**| **Description** |
|  ItemFinder |  Demonstrates new features in Full-Text Search, and best practices for efficiently locating data, caching, paging, and adding large object (LOB) data to the database.  |




####  {anchor:_Integration_Services}  Integration Services
**Samples in this section are not supported in SQL Server Express.**

| **Sample name**| **Description** |
|  ADO Source Component Sample |  The ADO Source Component sample demonstrates how to implement a source component that can be used as a data source in the Data Flow task. This component uses the ADO.NET connection manager to acquire a connection to a database, and runs the SQL statement provided by the user. The rows obtained by running the statement are added to a PipelineBuffer that is provided to the component by the Data Flow task, and subsequently made available to downstream components.  |
|  AWDataWarehouseRefresh Package Sample |  The AWDataWarehouseRefresh sample package illustrates how to create and populate user tables in the new AdventureWorksDW database, using data from the AdventureWorks database. Several Transact-SQL scripts are executed to create the tables, after which several Execute SQL tasks run to populate the tables.  |
|  Calculated Columns Package Sample |  The Calculated Columns sample is a package that processes archived sales transactions.  |
|  Capture Data Lineage Package Sample |  The Capture Data Lineage sample is a package that captures audit information. |
| Change Case Component Sample | The Change Case component sample demonstrates a transformation component with a synchronous output. This component changes the case of a character in a string by modifying a single character in the specified column as the rows pass through the component. |
| Create DataFlow Package Sample |  The Create DataFlow Package sample demonstrates how to programmatically create a package and add a Data Flow.  |
|  {anchor:CreatingaBasicPackage} Creating a Basic Package |  This sample is part of a tutorial and demonstrates creating a simple package which extracts data from an Excel workbook file and loads the data into a table in the AdventureWorks database.  |
|  {anchor:DeployingPackages} Deploying Packages |  This sample is part of a tutorial and demonstrates enhancing and deploying two packages.  |
| Creating a Simple ETL Package Lesson Packages | This sample contains completed packages for the lessons in the **Creating a Simple ETL Package** tutorial |
|  Creating a Custom Increment Task Sample |  The Increment Task sample demonstrates how to programmatically create custom tasks and their associated user interfaces.  |
|  Data Cleaning Package Sample |  The Data Cleaning sample is a package that cleans data.  |
|  DatasetDestination Component Sample |  The DatasetDestination sample demonstrates how to implement a custom destination component that is integrated into Business Intelligence Development Studio and can be added to a Data Flow task.  |
|  {anchor:EmailLogProvider} Email Log Provider |  The EmailLogProvider sample demonstrates how to create a custom log provider, the Email Log Provider, which sends logging output as an e-mail message in either plain text or HTML format.  |
|  {anchor:Excel2ConnectionManager} Excel2ConnectionManager |  The Excel2 Custom Connection Manager sample demonstrates how to create a custom connection manager, the Excel2 Connection Manager, and its associated user interface.  |
|  Execute Process Package Sample |  The Execute Process sample is a package that runs an executable from within the package.  |
|  Execute SQL Statements in a Loop Package Sample |  The Execute SQL Statements in a Loop sample package uses a Foreach Loop container to iterate through SQL statements saved in text files in a folder.  |
|  ForEachDirectory Sample |  This code sample demonstrates how to create a custom enumerator and a custom user interface to set properties for the enumerator using the .NET Framework and managed code.  |
|  {anchor:HtmlLogProvider} HtmlLogProvider |  The HtmlLogProvider sample demonstrates how to create a custom log provider, the Html Log Provider, which writes logging output to an HTML document.  |
|  Lookup Transformation | {anchor:LookupTransformation} The Lookup Transformation sample is a sample Integration Services package that implements the Lookup transformation in full cache mode using the Cache connection manager. The transformation performs lookups on a reference dataset that is stored in a text file. |
|  Process XML Data Package Sample |  The Process XML Data sample is a package that performs several sequential operations on a single XML data source.  |
|  Remove Duplicates Component Sample |  The Remove Duplicates sample demonstrates the implementation of a data flow transformation component with asynchronous outputs.  |
|  {anchor:RemoveDuplicatesUI} Remove Duplicates UI Component Sample  (December 2005) |  The Remove Duplicates sample with a custom user interface.  |
|  SMO Tables DBCC Package Sample |  The SMOTablesDBCC sample package illustrates how to enumerate the user tables in the AdventureWorks database by using the Foreach SMO enumerator in a Foreach Loop container.  |
|  SMOTableList Sample |  The SMOTableList sample illustrates how to enumerate the user tables in the AdventureWorks database.  |
|  {anchor:SqlConnectionManager} SqlConnectionManager Sample  (December 2005) |  Demonstrates how to programmatically create a custom connection manager. See the  [#PostReleaseNotes](#PostReleaseNotes)  for additional information on using this sample.  |




####  {anchor:_Notification_Services}  Notification Services
**Samples in this section are not supported in SQL Server 2008 and SQL Server Express.**

| **Sample name** | **Description** |
|  Flight |  The Flight sample is an event-driven Notification Services application that produces notifications about flight prices for subscribed users, according to their subscriptions.  |
|  Flight NMO |  The Flight NMO sample shows how to build the Flight sample application using the Notification Services Management Objects (NMO).  |
|  Inventory Tracker |  The Inventory Tracker sample shows how to use condition actions to allow subscribers to define their own query clauses for subscriptions.  |
|  Newsletter |  The Newsletter sample shows how to create a simple Web-based subscription management application. The sample has an n-tier design that contains an HTML-based interface layer and a subscription management middle-tier layer. A Microsoft Visual Studio Web project creates a Visual Web Developer Web Server when you run the Web project so that you can more easily use the sample.  |
|  Profit Margin |  The Profit Margin sample is an event-driven Notification Services application that produces notifications about profit margins for individual employees and sends this data to subscribed users. This sample uses the Analysis Services event provider to query an Analysis Services database and return the results as events to the Notification Services application.  |
|  Stock |  The Stock sample is a Notification Services application that uses both event-driven and scheduled subscriptions to produce notifications based on stock market data. Subscribed users receive notifications when the stock price goes above a specified trigger value.  |




####  {anchor:_Reporting_Services_1}  Reporting Services
*Reporting Services is available in SQL Server Express Edition with Advanced Services. Not all Reporting Services functionality is supported in this edition. For more information about supported and unsupported features, see the topic "Reporting Services in SQL Server Express Edition with Advanced Services" in SQL Server Books Online.

| **Sample name** | **Description** |
|  AdventureWorks Report Samples |  The AdventureWorks sample reports are a set of predefined report definition files that use the AdventureWorks databases as data sources. You can upload and view each report separately; however, some reports are designed to work together through the use of links. You can use the sample reports in two ways: to familiarize yourself with the capabilities of Reporting Services, or as templates for designing new reports.  |
|  AsynchronousRender Sample Windows Application |  AsynchronousRender is a sample Windows application developed using Visual Studio 2005. The application is based on a real-world scenario, and it demonstrates how to develop a Windows application that uses the Report Server Web service. The sample uses the Simple Object Access Protocol (SOAP) API to enable you to view the contents of a local report server, to select a report, and then to render that report to disk using asynchronous server communication.  |
|  File Share Data Processing Extension Sample |  FsiDataExtension is a simple data processing extension for the Windows file system. It uses the Microsoft .NET Framework library classes **DirectoryInfo** and **FileSystemInfo** to query the contents of any valid network file share. **This sample is not supported in SQL Server Express.** |
|  FindRenderSave Sample Windows Application |  Demonstrates how to develop a Windows application that uses the Report Server Web service. The sample uses the Simple Object Access Protocol (SOAP) API to enable you to search for reports in the report server database, to review the report properties and to render the reports to various on-disk formats.  |
|  Forms Authentication Sample |  Uses Microsoft Visual C# to show how to implement a security extension for Reporting Services. The sample uses Forms Authentication along with SQL Server to provide a custom security model that works with Reporting Services.  |
|  {anchor:Polygons} Polygons Custom Report Item   (December 2005) |  Uses Microsoft Visual C# to show how to implement a simple custom report item sample. This sample uses the **System.Component** classes from the Microsoft .NET Framework and classes from the **Microsoft.ReportDesigner** and **Microsoft.ReportingServices** namespaces to implement a custom report item run-time component and design-time component that can be used in a hosted design environment.  |
|  Printer Delivery Extension Sample |  The Printer Delivery Sample is a sample delivery extension that offers an introduction to Reporting Services delivery. The sample is a simple delivery extension for a printer. It uses the IMAGE rendering extension, along with the **System.Drawing.Printing** namespace in the Microsoft .NET Framework, to deliver a report to a printer.  |
|  {anchor:ReportBuilder} Report Builder Report Samples   (December 2005) |  Describes a report sample that you can access directly from the report server and modify in Report Builder. **This sample is not supported in SQL Server Express.** |
|  Report Model Samples |  The purpose of this sample is to show SQL Server Reporting Services Model Designer/Report Builder users how report models are structured and how report models are used in Report Builder. **This sample is not supported in SQL Server Express.** |
|  {anchor:ReportSearch} ReportSearch Sample Application   (December 2005) |  Shows how to add search functionality to Office 2003 applications so that users can browse a report server and view Reporting Services reports.  |
|  RSExplorer Sample Application |  Demonstrates how to develop a Windows application that uses the Reporting Services Web service. RSExplorer uses a Microsoft .NET Framework proxy class to call Web service methods exposed by the Reporting Services SOAP API. It also highlights new features in the area of enterprise reporting.  |
|  Script Samples |  AddItemSecurity script sample demonstrates how to use a script to set item security policies in the report server namespace. CancelRunningJobs script sample demonstrates a sample administration script that cancels jobs that are running on a report server. **This sample is not supported in SQL Server Express. ** ConfigureSystemProperties script sample demonstrates a script that can be used to set system-level, report server properties. PublishSampleReports script sample demonstrates a script that publishes the sample reports to a report server.  |
|  Server Management Report Samples |  Server Management reports are a set of predefined report definition files that use SQL Server metadata as a source of information for reports. You can use the sample reports in two ways: to view server information, or as templates for designing new reports. Execution Log sample reports includes predefined report files, sample database scripts, and a sample SQL Server Integration Services package that you can use to view execution log data for a report server. **The following reports are not supported in SQL Server Express: Sales Reason Comparison, Execution Log reports.** |


 {anchor:PostReleaseNotes} Post Release Notes: 
The BulkCopySelectResult Data Access (ODBC) sample requires a simple change before it can be successfully used. Capitalize the letter "D" in the word "Birthdate" on line 51 of BulkCopySelectResult.cpp.
