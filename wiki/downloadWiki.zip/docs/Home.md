# Microsoft SQL Server Community Projects & Samples
The **SQL Server 2012 RTM ** versions of the Adventure Works OLTP sample database and Adventure Works data warehouse sample database are available on [AdventureWorks for SQL Server 2012](http://msftdbprodsamples.codeplex.com/releases/view/55330).

**SQL Server 2008R2** product code samples are available [here](http://sqlserversamples.codeplex.com/Releases/). [Download the AdventureWorks 2008R2 family of sample databases and AdventureWorks 2008R2 sample databases](http://msftdbprodsamples.codeplex.com/Releases/) 

Note: When you click the big **Download** button on the SQL Server R2 sample code project page (this one),  you will get the x64 installer and download the **SQL Server 2008R2** samples. 

**SQL Azure** AdventureWorks community sample databases can be downloaded from [here](http://msftdbprodsamples.codeplex.com/Release/ProjectReleases.aspx?ReleaseId=37304).

**SQL Server 2008** code samples are available [here](http://sqlserversamples.codeplex.com/releases/view/30803). [Download the AdventureWorks 2008 family of sample databases](http://msftdbprodsamples.codeplex.com/releases/view/37109) separately.

**SQL Server 2005** product samples can still be [downloaded](http://www.codeplex.com/SqlServerSamples/Release/ProjectReleases.aspx?ReleaseId=4000) and separately [AdventureWorks for SQL Server 2005](http://www.codeplex.com/MSFTDBProdSamples/Release/ProjectReleases.aspx?ReleaseId=4004).

[CodePlex](http://www.codeplex.com/SqlServerSamples) is the project hosting site for Microsoft SQL Server Samples and Community Projects. Projects listed here are official Microsoft samples for SQL Server (released with Service Packs or major releases of SQL Server) and applications developed by MVPs, and the SQL Server community at large, including:
* [Forums & Answers](#forums)
* [Microsoft Product Samples All-in-One](#monolith)
* [Sample Databases](#databases)
* [End to End Samples](#e2e)
* [Master Data Services in SQL Server 2012](#masterdata)
* [Microsoft SQL Server Analysis Services](#ssas)
* [Microsoft SQL Server Database Engine](#engine)
* [Microsoft SQL Server Integration Services](#ssis)
* [Microsoft SQL Server Reporting Services](#ssrs)
* [Spatial](#spatial)
* [StreamInsight](#streaminsight)
* [Microsoft Sync Framework](#sync)
* [Platform Tools & Utilities](#utilities)
* [SSDS & Cloud Samples](#cloud)
_Unless noted otherwise, the download links are for the latest release of the project; see the individual project sites (on the Releases tab) for prior version releases._ Most projects have more than one file download for a given release; read carefully to be sure you choose the ones that you need.

## {anchor:monolith}Microsoft Product Samples
Note: This is one monolithic set of all Microsoft SQL Server product samples (except for the sample databases, due to size constraints) and does NOT include any community projects. If you are interested in a specific subject area, links to download individual technology-focused samples are below.
||Project||Project Site||Download||
|All Microsoft Product Samples in a Box|This page|[Download](https://www.codeplex.com/Release/ProjectReleases.aspx?ProjectName=SqlServerSamples)|

## {anchor:databases}Sample Databases
||Project||Project Site||Download||
|Microsoft Sample Databases|[Project Site](http://www.codeplex.com/MSFTDBProdSamples/)|[Download](http://www.codeplex.com/MSFTDBProdSamples/Release/ProjectReleases.aspx)|
|VSTS DB Edition Sample DB Projects|[Project Site](http://code.msdn.microsoft.com/dbpromsdbsamples)|[Download](http://code.msdn.microsoft.com/dbpromsdbsamples/Release/ProjectReleases.aspx)|
|Northwind Community Edition|[Project Site](http://www.codeplex.com/NorthwindCommunity/)|No Releases Yet|
|SQL Server 2000 Sample DBs|[Project Site](http://code.msdn.microsoft.com/northwind/)|[Download](https://code.msdn.microsoft.com/Release/ProjectReleases.aspx?ProjectName=northwind)|

## {anchor:forums}Forums & Answers
||Project||Project Site||
|SQL Server Community & Samples Discussion Forum|[Discussion Forum](http://social.msdn.microsoft.com/Forums/en-us/sqlserversamples/threads)|
|SQL Server Community & Samples FAQ|[Wiki Page](http://www.codeplex.com/SqlServerSamples/Wiki/View.aspx?title=HowToUseCodePlex&referringTitle=Home)|
|Why upgrade to SQL Server 2008?|[Website](http://www.microsoft.com/sqlserver/2008/en/us/why-upgrade.aspx)|
|Microsoft TechNet SQL Server TechCenter|[Website](http://technet.microsoft.com/en-us/sqlserver/default.aspx)|
|Microsoft MSDN SQL Server Developer Center|[Website](http://msdn2.microsoft.com/en-us/sqlserver/default.aspx)|
|SQL Server Forums|[Discussion Forums Index](http://forums.microsoft.com/MSDN/default.aspx?ForumGroupID=19&SiteID=1)|
|SQL Server 2008 (Katmai) Forums|[Discussion Forums Index](http://forums.microsoft.com/MSDN/default.aspx?ForumGroupID=428&SiteID=1)|
|SQL Examples by MVPs (answers from the forums)|[Wiki Page](http://code.msdn.microsoft.com/SQLExamples)|
|SQL Server Community Worldwide|[Website](http://www.sqlcommunity.com/)|
|What clients can I use for source control with CodePlex?|[Wiki Page](http://www.codeplex.com/CodePlex/Wiki/View.aspx?title=Source%20control%20clients&referringTitle=CodePlex%20Help%20Wiki)|

## {anchor:cloud}SQL Server Data Services/Cloud Samples
||Project||Project Site||Download||
|SQL Server Data Services Developer Center|[Project Site](http://msdn.microsoft.com/en-gb/sqlserver/dataservices/default.aspx)| |
|SSDS Examples|[Project Site](http://www.codeplex.com/ssdsexamples/)|[Download](http://www.codeplex.com/ssdsexamples/Release/ProjectReleases.aspx)|

## {anchor:e2e}End to End (multi-technology, complete, integrated)
||Project||Project Site||Download||
|SQL Server 2008 SQL RSS|[Project Site](http://www.codeplex.com/SQLRSS/)|[Download](http://www.codeplex.com/SQLRSS/Release/ProjectReleases.aspx)|
|SQL Server 2008 Fault Retry Provider|[Project Site](http://www.codeplex.com/SqlFaultRetryProvide/)|[Download](http://www.codeplex.com/SqlFaultRetryProvide/Release/ProjectReleases.aspx)|
|Microsoft End-to-End Samples|[Project Site](http://www.codeplex.com/MSFTEEProdSamples)|[Download](https://www.codeplex.com/Release/ProjectReleases.aspx?ProjectName=MSFTEEProdSamples)|
|Community End-to-End Samples Gallery (sponsored by DPE) |[Project Site](http://www.codeplex.com/SQLSrvE2E)|[Download](https://www.codeplex.com/Release/ProjectReleases.aspx?ProjectName=SQLSrvE2E)|
|Tailspin Travel Sample|[Project Site](http://tailspintravel.codeplex.com/)|[Download](http://tailspintravel.codeplex.com/Release/ProjectReleases.aspx)|

## {anchor:masterdata}Master Data Services in SQL Server 2012
||Project||Project Site||Download||
|Master Data Services in SQL Server 2012|[Project Site](http://sqlserversamples.codeplex.com/wikipage?title=SQL%20Server%202012%20Master%20Data%20Services%20&IsNewlyCreatedPage=true)]|[Download](http://sqlserversamples.codeplex.com/wikipage?title=SQL%20Server%202012%20Master%20Data%20Services%20&IsNewlyCreatedPage=true)]|

## {anchor:ssas}Microsoft SQL Server Analysis Services
||Project||Project Site||Download||
|Microsoft Samples (OLAP, Data Mining, Administration)|[Project Site](http://www.codeplex.com/MSFTASProdSamples)|[Download](https://www.codeplex.com/Release/ProjectReleases.aspx?ProjectName=MSFTASProdSamples)|
|Community Analysis Services Samples Gallery|[Project Site](http://www.codeplex.com/SQLSrvAnalysisSrvcs)|[Download](https://www.codeplex.com/Release/ProjectReleases.aspx?ProjectName=SQLSrvAnalysisSrvcs)|
|Analysis Services Stored Procedures|[Project Site](http://www.codeplex.com/ASStoredProcedures)|[Download](http://www.codeplex.com/ASStoredProcedures/Release/ProjectReleases.aspx)|
|MDX Script Performance Analyzer|[Project Site](http://www.codeplex.com/mdxscriptperf/)|[Download](http://www.codeplex.com/mdxscriptperf/Release/ProjectReleases.aspx)|
|powerSSAS: A PowerShell provider for SQL Server Analysis Services|[Project Site](http://www.codeplex.com/powerSSAS/)|[Download](http://www.codeplex.com/powerSSAS/Release/ProjectReleases.aspx)|

## {anchor:engine}Microsoft SQL Server Database Engine
||Project||Project Site||Download||
|Microsoft Database Engine Samples (CLR, Full Text, SMO) |[Project Site](http://www.codeplex.com/MSFTEngProdSamples/)|[Download](http://www.codeplex.com/MSFTEngProdSamples/Release/ProjectReleases.aspx)|
|Microsoft Data Programmability Samples (ADO.NET, OLEDB, ODBC) |[Project Site](http://www.codeplex.com/MSFTDPProdSamples/)|[Download](http://www.codeplex.com/MSFTDPProdSamples/Release/ProjectReleases.aspx)|
|Microsoft Replication Samples|[Project Site](http://www.codeplex.com/MSFTReplProdSamples/)|[Download](http://www.codeplex.com/MSFTReplProdSamples/Release/ProjectReleases.aspx)|
|Microsoft Service Broker Samples|[Project Site](http://www.codeplex.com/MSFTSBProdSamples/)|[Download](http://www.codeplex.com/MSFTSBProdSamples/Release/ProjectReleases.aspx)|
|Community Service Broker Samples|[Project Site](http://www.codeplex.com/SQLSrvSrvcBrkr/)|[Download](http://www.codeplex.com/SQLSrvSrvcBrkr/Release/ProjectReleases.aspx)|
|Microsoft Transact-SQL Sample Scripts|[Project Site](http://www.codeplex.com/MSFTScrptProdSamples/)|[Download](http://www.codeplex.com/MSFTScrptProdSamples/Release/ProjectReleases.aspx)|
|Microsoft XML Samples|[Project Site](http://www.codeplex.com/MSFTXmlProdSamples/)|[Download](http://www.codeplex.com/MSFTXmlProdSamples/Release/ProjectReleases.aspx)|
|Microsoft TechNet SQL Server Scripting Center|[Project Site](http://www.microsoft.com/technet/scriptcenter/hubs/sqlserver.mspx)| |
|SQL Server 2D Matrix Builder|[Project Site](http://www.codeplex.com/SQL2DMatrixBuilder/)|[Download](http://www.codeplex.com/SQL2DMatrixBuilder/Release/ProjectReleases.aspx)|
|SQL 2008 Extended Events Manager|[Project Site](http://www.codeplex.com/ExtendedEventManager/)|[Download](http://www.codeplex.com/ExtendedEventManager/Release/ProjectReleases.aspx)|
|Allocation SQL Server Management Studio Add-in|[Project Site](http://www.codeplex.com/SSMSAllocation)|[Download](http://www.codeplex.com/SSMSAllocation/Release/ProjectReleases.aspx)|
|Open DBDiff|[Project Site](http://www.codeplex.com/OpenDBiff/)|[Download](http://www.codeplex.com/OpenDBiff/Release/ProjectReleases.aspx)|
|ADO.NET Entity Framework Extensions|[Project Site](http://code.msdn.microsoft.com/EFExtensions/)|[Download](http://code.msdn.microsoft.com/EFExtensions/Release/ProjectReleases.aspx)|
|Perseus: Entity Framework EntityBag|[Project Site](http://code.msdn.microsoft.com/entitybag/)|[Download](http://code.msdn.microsoft.com/entitybag/Release/ProjectReleases.aspx)|
|SQL CLR Measure Time|[Project Site](http://www.codeplex.com/SqlClrMeasureTime/)|[Download](http://www.codeplex.com/SqlClrMeasureTime/Release/ProjectReleases.aspx)|
|ADO.NET Entity Framework & LINQ to Relational Data|[Project Site](http://code.msdn.microsoft.com/adonetefx/)| |
|XML Toolkits & Extensions|[Project Site](http://code.msdn.microsoft.com/xml/)| |

## {anchor:ssis}Microsoft SQL Server Integration Services
||Project||Project Site||Download||
|Microsoft Integration Services Samples|[Project Site](http://www.codeplex.com/MSFTISProdSamples/)|[Download](http://www.codeplex.com/MSFTISProdSamples/Release/ProjectReleases.aspx)|
|Community Integration Services Samples Gallery|[Project Site](http://www.codeplex.com/SQLSrvIntegrationSrv)|[Download](http://www.codeplex.com/SQLSrvIntegrationSrv/Release/ProjectReleases.aspx)|
|Metadata Driven ETL Management Studio (MDDE) |[Project Site](http://www.codeplex.com/SQLServerMDDEStudio/)|[Download](http://www.codeplex.com/SQLServerMDDEStudio/Release/ProjectReleases.aspx)|
|ssisUnit|[Project Site](http://www.codeplex.com/ssisUnit/)|[Download](http://www.codeplex.com/ssisUnit/Release/ProjectReleases.aspx)|
|MapPoint Batch Geocoder for SSIS|[Project Site](http://www.codeplex.com/MapPointBatchGeocode/)|[Download](http://www.codeplex.com/MapPointBatchGeocode/Release/ProjectReleases.aspx)|
|Vulcan|[Project Site](http://www.codeplex.com/vulcan/)|No Releases Yet|
|Integration Services Performance Strategies|[Whitepaper](http://www.microsoft.com/technet/prodtechnol/sql/2005/technologies/ssisperfstrat.mspx)| |
|SCD Component for Kimball Model DWs|[Project Site](http://www.codeplex.com/kimballscd/)|[Download](http://www.codeplex.com/kimballscd/Release/ProjectReleases.aspx)|
|ssisTwitterSuite via REST|[Project Site](http://www.codeplex.com/SSISTwitterSuite/)|[Download](http://www.codeplex.com/SSISTwitterSuite/Release/ProjectReleases.aspx)|
|SSIS Configuration Manager|[Project Site](http://www.codeplex.com/SSISConfig/)|[Download](http://www.codeplex.com/SSISConfig/Release/ProjectReleases.aspx)|
|DTLoggedExec|[Project Site](http://www.codeplex.com/DTLoggedExec/)|[Download](http://www.codeplex.com/DTLoggedExec/)|

## {anchor:ssrs}Microsoft SQL Server Reporting Services
||Project||Project Site||Download||
|Microsoft Reporting Services Samples|[Project Site](http://www.codeplex.com/MSFTRSProdSamples/)|[Download](http://www.codeplex.com/MSFTRSProdSamples/Release/ProjectReleases.aspx)|
|ReportServer Explorer|[Project Site](http://www.codeplex.com/RSSExplorer/)|[Download](http://www.codeplex.com/RSSExplorer/Release/ProjectReleases.aspx)|
|SQL Server 2005 Report Packs| |[Download](http://www.microsoft.com/downloads/details.aspx?FamilyID=d81722ce-408c-4fb6-a429-2a7ecd62f674&DisplayLang=en)|

## {anchor:spatial}Microsoft SQL Server Spatial Tools
||Project||Project Site||Download||
|SQL Server Spatial Tools|[Project Site](http://www.codeplex.com/sqlspatialtools/)|[Download](http://www.codeplex.com/sqlspatialtools/Release/ProjectReleases.aspx)|
|Spatial Data Support in SQL Server 2008|[Project Site](http://code.msdn.microsoft.com/mag200902DBDev/)|[Download](http://code.msdn.microsoft.com/mag200902DBDev/Release/ProjectReleases.aspx)|

## {anchor:streaminsight}StreamInsight
||Project||Project Site||
|StreamInsight Samples|[Project Site](http://streaminsight.codeplex.com/)|

## {anchor:sync}Microsoft Sync Framework
||Project||Project Site||Download||
|Sync101 - Getting Started with Sync V1.0 CTP2|[Project Site](http://code.msdn.microsoft.com/sync/)|[Download](http://code.msdn.microsoft.com/Release/ProjectReleases.aspx?ProjectName=sync&ReleaseId=615)|
|Contact Synchronization Sample - Outlook Sync|[Project Site](http://code.msdn.microsoft.com/sync/)|[Download](http://code.msdn.microsoft.com/Release/ProjectReleases.aspx?ProjectName=sync&ReleaseId=613)|
|Sync Framework Tutorial|[Project Site](http://code.msdn.microsoft.com/sync/)|[Download](http://code.msdn.microsoft.com/sync/Release/ProjectReleases.aspx?ReleaseId=949)|
|Producing and Consuming FeedSync Feeds using Sync|[Project Site](http://code.msdn.microsoft.com/sync/)|[Download](http://code.msdn.microsoft.com/Release/ProjectReleases.aspx?ProjectName=sync&ReleaseId=849)|

## {anchor:utilities}Platform Tools & Utilities
||Project||Project Site||Download||
|BIDS Helper for Visual Studio/SQL Server (2005 & 2008)|[Project Site](http://www.codeplex.com/bidshelper/)|[Download](http://www.codeplex.com/bidshelper/Release/ProjectReleases.aspx)|
|SqlMonitoring Tool|[Project Site](http://www.codeplex.com/sqlmonitoring)|[Download](http://www.codeplex.com/sqlmonitoring/Release/ProjectReleases.aspx)|
|SQL Server Health & History|[Project Site](http://www.codeplex.com/sqlh2/)|[Download](http://www.codeplex.com/sqlh2/Release/ProjectReleases.aspx)|
|SQL Load Generator|[Project Site](http://www.codeplex.com/SqlLoadGenerator/)|[Download](http://www.codeplex.com/SqlLoadGenerator/Release/ProjectReleases.aspx)|
|SQL Server 2005 Metadata Toolkit|[Project Site](http://code.msdn.microsoft.com/SqlServerMetadata/)|[Download](http://code.msdn.microsoft.com/Release/ProjectReleases.aspx?ProjectName=SqlServerMetadata)|
|DMV Stats performance data warehouse (for SQL Server 2005)|[Project Site](http://www.codeplex.com/sqldmvstats/)|[Download](http://www.codeplex.com/sqldmvstats/Release/ProjectReleases.aspx)|
|SQL Nexus performance analysis tool |[Project Site](http://www.codeplex.com/sqlnexus/)|[Download](http://www.codeplex.com/sqlnexus/Release/ProjectReleases.aspx)|
|SQL Server 2005 Service Manager |[Project Site](http://www.codeplex.com/SQL2005SrvcMngr/)|[Download](http://www.codeplex.com/SQL2005SrvcMngr/Release/ProjectReleases.aspx)|
|SQL Server Hosting Toolkit |[Project Site](http://www.codeplex.com/sqlhost/)|[Download](http://www.codeplex.com/sqlhost/Release/ProjectReleases.aspx)|
|SQL Web Data Administrator |[Project Site](http://www.codeplex.com/SqlWebAdmin/)|[Download](http://www.codeplex.com/SqlWebAdmin/Release/ProjectReleases.aspx)|
|SQL Web Query|[Project Site](http://www.codeplex.com/SQLWebQuery/)|[Download](http://www.codeplex.com/SQLWebQuery/Release/ProjectReleases.aspx)|
|SQL Server 2005 Driver for PHP|[Project Site](http://www.codeplex.com/SQL2K5PHP/)|[Download](http://www.microsoft.com/downloads/details.aspx?FamilyID=85f99a70-5df5-4558-991f-8aee8506833c&displaylang=en)|
|MassDataHandler for Unit Testing|[Project Site](http://www.codeplex.com/MassDataHandler/)|[Download](http://www.codeplex.com/MassDataHandler/Release/ProjectReleases.aspx)|
|Scriptio|[Project Site](http://www.codeplex.com/scriptio/)|[Download](http://www.codeplex.com/scriptio/Release/ProjectReleases.aspx)|
|T-SQL Macro for Unit Testing|[Project Site](http://datamanipulation.net/tsqlmacro/)| |
|SQL Server 2005 FineBuild|[Project Site](http://www.codeplex.com/SQLServerFineBuild/)|[Download](http://www.codeplex.com/SQLServerFineBuild/Release/ProjectReleases.aspx)|
|OpenDBDiff|[Project Site](http://www.codeplex.com/OpenDBiff/)|[Download](http://www.codeplex.com/OpenDBiff/Release/ProjectReleases.aspx)|
|SQL Server Gadgets for Vista|[Project Site](http://www.codeplex.com/SQLServerGadgets/)|[Download](http://www.codeplex.com/SQLServerGadgets/Release/ProjectReleases.aspx)|
|SQL Utilities|[Project Site](http://code.msdn.microsoft.com/SQLUtilities/)|[Download](http://code.msdn.microsoft.com/SQLUtilities/Release/ProjectReleases.aspx)|
|Sql Server Backup Utility|[Project Site](http://www.codeplex.com/SqlBackup/)|[Download](http://www.codeplex.com/SqlBackup/Release/ProjectReleases.aspx)|

**SQL Heroes 2008 Contest Winners**
These awesome contributors took home a Windows Home Server (HP MediaSmart ex470) from SQL PASS 2008 for their great contributions to SQL Server community projects. We're proud to have such smart folks in our community!!

|BIDS Helper for Visual Studio/SQL Server (2005 & 2008)|Greg Galloway, Darren Gosbell, John Calvin Welch|[Project Site](http://www.codeplex.com/bidshelper/)|
|SQL 2008 Extended Events Manager|Jonathan Matthew Kehayias|[Project Site](http://www.codeplex.com/ExtendedEventManager/)|
|ssisUnit|John Calvin Welch|[Project Site](http://www.codeplex.com/ssisUnit/) |
|SqlMonitoring Tool|Robert Hartskeerl|[Project Site](http://www.codeplex.com/sqlmonitoring)|
|Allocation SQL Server Management Studio Add-in|Daniel Gould|[Project Site](http://www.codeplex.com/SSMSAllocation)|
